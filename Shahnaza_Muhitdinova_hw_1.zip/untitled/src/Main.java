import java.util.Scanner;
import java.util.SortedMap;

public class Main {
    public static void main(String[] args) {
        String iLoveMyFamily;
        final int NUM = 100;
        String word = "FLower";
        iLoveMyFamily = NUM + word;
        System.out.println(iLoveMyFamily);

        if (NUM > 0) {
            System.out.println("Вы сохранили отрицательное число");
        } else if (NUM > 0){
            System.out.println("Вы сохранили  положительное число");
        } else {
            System.out.println ("Вы сохранили ноль");
        }

        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите ваше имя:");
        String name = scanner.nextLine();
        System.out.println("Hello " + name + "!");


    }
}